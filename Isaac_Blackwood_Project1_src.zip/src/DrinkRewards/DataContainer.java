package DrinkRewards;

abstract class DataContainer 
{
	//test to see if the data container is contains data that makes sense
	abstract boolean isValid();
}
